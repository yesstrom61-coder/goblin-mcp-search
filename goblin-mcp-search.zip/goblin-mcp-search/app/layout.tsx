export const metadata = {
  title: "Goblin MCP Search",
  description: "Web search MCP server for local llama.cpp goblin"
};

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
