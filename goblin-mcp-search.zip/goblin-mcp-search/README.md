# Goblin MCP Search

A minimal Vercel/Next.js MCP server for web search and source fetching.

## Tools

- `web_search` — Brave web search snippets/results
- `fetch_url` — fetch readable text from a source URL
- `search_and_fetch` — search and fetch top source pages

## Deploy

1. Upload this repo to GitHub.
2. Import the GitHub repo into Vercel.
3. Add this Vercel environment variable:

```text
BRAVE_SEARCH_API_KEY=your_key
```

4. Deploy.
5. MCP endpoint:

```text
https://YOUR-PROJECT.vercel.app/api/mcp
```

## Notes

This uses Brave Search API for search and simple HTML cleaning for URL fetching.
